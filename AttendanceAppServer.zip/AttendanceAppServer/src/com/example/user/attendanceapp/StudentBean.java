package com.example.user.attendanceapp;

import java.io.Serializable;

public class StudentBean implements Serializable{
	private static final long serialVersionUID=1L;
	private String roll;
	private String name;
	public String getRoll() {
		return roll;
	}
	public void setRoll(String roll) {
		this.roll = roll;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

}
