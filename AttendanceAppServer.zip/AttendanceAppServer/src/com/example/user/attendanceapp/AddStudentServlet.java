package com.example.user.attendanceapp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class AddStudentServlet
 */
@WebServlet("/addstudent")
public class AddStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session=req.getSession(false);
		String user=(String)session.getAttribute("user");
		if(user==null){
		res.sendRedirect("/AttendanceAppServer/");
		}
		String roll=req.getParameter("roll");
		String name=req.getParameter("name");
		String stream=req.getParameter("stream");
		String contact=req.getParameter("contact");
		RequestDispatcher rd;
		String sql = "insert into student values(?,?,?,?)";
		PreparedStatement pstmt;
		try {
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendanceapp","root","");  
					pstmt=(PreparedStatement) con.prepareStatement(sql);
					pstmt.setString(1,roll);
					pstmt.setString(2,name);
					pstmt.setString(3,stream);
					pstmt.setString(4, contact);
					pstmt.executeUpdate();
				
						
						rd=req.getRequestDispatcher("/home.jsp");
						rd.forward(req, res);
					
		
		}catch (Exception e) {
			// TODO: handle exception
		}

	}

}
