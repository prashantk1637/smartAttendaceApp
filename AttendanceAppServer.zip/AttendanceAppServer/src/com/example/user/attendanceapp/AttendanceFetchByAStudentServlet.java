package com.example.user.attendanceapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;

@WebServlet("/student")
public class AttendanceFetchByAStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String roll=request.getParameter("roll");
		PrintWriter out =response.getWriter();
		String sql="select course,status from attendancereport where studentroll=?";
		RequestDispatcher rd;
		PreparedStatement pstmt;
		HashMap<String, Integer> map=new HashMap<>();
		String report="";
		String data="";
		try {
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendanceapp","root","");  
					pstmt=(PreparedStatement) con.prepareStatement(sql);
					pstmt.setString(1, roll);
					ResultSet rs=(ResultSet) pstmt.executeQuery();
					while(rs.next())
					{
						report+=rs.getString(1)+":"+rs.getString(2)+":";
					
					}
					//out.println(report);
					String[] reportArr=report.split(":");
					for(int i=0;i<reportArr.length;i++)
					{
						Integer x=map.get(reportArr[i]);
						if(x==null)
						{	if(reportArr[i+1].equals("Present"))	
							map.put(reportArr[i], 1);
							
						}
						else
						{
							if(reportArr[i+1].equals("Present"))	
								map.put(reportArr[i], x+1);
						}
						i++;
							
					}
					for(String key: map.keySet())
					{
						data+=key+"                                "+map.get(key)+":";
					}
					out.println(data);
					
		}catch (Exception e) {
			
		}
	
	
	
	
	}

}
