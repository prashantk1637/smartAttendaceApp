package com.example.user.attendanceapp;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import java.io.*;
/**
 * Servlet implementation class FetchCourseServlet
 */
@WebServlet("/fetchcourse")
public class FetchCourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FetchCourseServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session=req.getSession(false);
		//String user=(String)session.getAttribute("user");
		//if(user==null){
		//res.sendRedirect("/AttendanceAppServer/");
		//}
		String username=req.getParameter("user");
		RequestDispatcher rd;
		//CourseBean obj=null;
		String sql="select cid from teacher_course where tid=?";
		PreparedStatement pstmt;
		try {
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendanceapp","root","");  
					pstmt=(PreparedStatement) con.prepareStatement(sql);
					pstmt.setString(1,username);
					
					ResultSet rs=(ResultSet) pstmt.executeQuery();
					ArrayList<CourseBean> courseList=new ArrayList<>();
					PrintWriter out=res.getWriter();
					while(rs.next())
					{
						//out.println("Course id "+rs.getString(1));
						String sql1="select name from course where cid=?";
						pstmt=(PreparedStatement) con.prepareStatement(sql1);
						pstmt.setString(1, rs.getString(1));
						ResultSet rs1=(ResultSet) pstmt.executeQuery();
						if(rs1.next())
						{
							CourseBean obj=new CourseBean();
							obj.setCourseName(rs1.getString(1));
							courseList.add(obj);
						}
						
					}
					
					for(CourseBean c:courseList)
					{
						out.print(c.getCourseName()+":");
					}
		
		}catch (Exception e) {
			// TODO: handle exception
		}
	}

}
