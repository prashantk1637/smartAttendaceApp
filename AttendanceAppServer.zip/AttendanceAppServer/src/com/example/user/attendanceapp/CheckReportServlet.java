package com.example.user.attendanceapp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;

/**
 * Servlet implementation class CheckReportServlet
 */
@WebServlet("/checkreport")
public class CheckReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckReportServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		ArrayList<AttendanceReportBean> result=new ArrayList<>();
		String sql="select * from attendancereport";
		RequestDispatcher rd;
		PreparedStatement pstmt;
		try {
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendanceapp","root","");  
					pstmt=(PreparedStatement) con.prepareStatement(sql);
					ResultSet rs=(ResultSet) pstmt.executeQuery();
					while(rs.next())
					{
						AttendanceReportBean obj=new AttendanceReportBean();
						obj.setTeacherName(rs.getString(1));
						obj.setCourseName(rs.getString(2));
						obj.setTime(rs.getString(3));
						obj.setStudentRoll(rs.getString(4));
						obj.setStudentName(rs.getString(5));
						obj.setStatus(rs.getString(6));
						result.add(obj);
						}
					req.setAttribute("RESULT", result);
					rd=req.getRequestDispatcher("Report.jsp");
					rd.forward(req, res);
		}catch(Exception e){}
	}

}				
