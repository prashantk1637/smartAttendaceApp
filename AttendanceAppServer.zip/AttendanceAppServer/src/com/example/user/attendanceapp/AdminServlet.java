package com.example.user.attendanceapp;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/login")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String username=req.getParameter("user");
		String password=req.getParameter("pass");
		RequestDispatcher rd;
		String sql="select user, pass,type from login where user=? and pass=?";
		PreparedStatement pstmt;
		try {
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendanceapp","root","");  
					pstmt=(PreparedStatement) con.prepareStatement(sql);
					pstmt.setString(1,username);
					pstmt.setString(2,password);
					ResultSet rs=(ResultSet) pstmt.executeQuery();
					if(rs.next())
					{
						if(rs.getString(1).equals(username)&& rs.getString(2).equals(password)&&rs.getString(3).equals("admin"))
						{	HttpSession s=req.getSession(true);
							s.setAttribute("user",rs.getString(1));
							rd=req.getRequestDispatcher("home.jsp");
							rd.forward(req, res);
						}
						else{
							req.setAttribute("error", "Sorry!!Only Admin Access");
							req.setAttribute("note", "Note:-Teachers and students can login to their account through App only.");
							rd=req.getRequestDispatcher("index.jsp");
							rd.forward(req, res);
						}
					}
					else
					{
						req.setAttribute("error", "Wrong credentials");
						req.setAttribute("note", "Make sure your password");
						rd=req.getRequestDispatcher("index.jsp");
						rd.forward(req, res);
					}
		
		}catch (Exception e) {
			// TODO: handle exception
		}

	}
}
