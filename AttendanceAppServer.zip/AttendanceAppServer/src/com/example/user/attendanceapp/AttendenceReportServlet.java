package com.example.user.attendanceapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class AttendenceReportServlet
 */
@WebServlet("/report")
public class AttendenceReportServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AttendenceReportServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String report=req.getParameter("report");
		String reportArray[]=report.split("#");
		String teacher=reportArray[0];
		String course=reportArray[1];
		String time=reportArray[2];
		String sql = "insert into attendancereport values(?,?,?,?,?,?)";
		int inserted=0;
		PrintWriter out =res.getWriter();
		PreparedStatement pstmt;
		try {
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendanceapp","root","");  
					pstmt=(PreparedStatement) con.prepareStatement(sql);
					for(int i=3;i<reportArray.length;i++)
					{	pstmt.setString(1, teacher);
						pstmt.setString(2, course);
						pstmt.setString(3, time);
						pstmt.setString(4, reportArray[i]);
						pstmt.setString(5, reportArray[i+1]);
						pstmt.setString(6, reportArray[i+2]);
						inserted=pstmt.executeUpdate();
						i++;
						i++;
					}
					if(inserted>0)
						out.println(""+inserted);
						
					
		
		}catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
