package com.example.user.attendanceapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;

/**
 * Servlet implementation class StudentFetchServlet
 */
@WebServlet("/fetchstudent")
public class StudentFetchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String course=req.getParameter("course");
		RequestDispatcher rd;
		String sql="select cid from course where name=?";
		PrintWriter out=res.getWriter();
		PreparedStatement pstmt;
		try {
					Class.forName("com.mysql.jdbc.Driver");  
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendanceapp","root","");  
					pstmt=(PreparedStatement) con.prepareStatement(sql);
					pstmt.setString(1,course);
					ResultSet rs=(ResultSet) pstmt.executeQuery();
					ArrayList<StudentBean> studentList=new ArrayList<>();
					if(rs.next())
					{
						String sql1="select roll from student_course where cid=? order by roll";
						pstmt=(PreparedStatement) con.prepareStatement(sql1);
						pstmt.setString(1, rs.getString(1));
						ResultSet rs1=(ResultSet) pstmt.executeQuery();
						while(rs1.next())
						{
							//out.println(rs1.getString(1));
							String sql2="select roll,name from student where roll=?";
							pstmt=(PreparedStatement) con.prepareStatement(sql2);
							pstmt.setString(1, rs1.getString(1));
							ResultSet rs2=(ResultSet) pstmt.executeQuery();
							if(rs2.next()){
								
									StudentBean obj=new StudentBean();
									obj.setRoll(rs2.getString(1));
									obj.setName(rs2.getString(2));
									studentList.add(obj);
							}
						}
						
					}
					
					for(StudentBean s:studentList)
					{
						out.print(s.getRoll()+":"+s.getName()+":");
					}
		
		}catch (Exception e) {
			// TODO: handle exception
		}	
	
	}

}
