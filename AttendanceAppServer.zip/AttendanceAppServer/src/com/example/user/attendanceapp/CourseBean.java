package com.example.user.attendanceapp;

import java.io.Serializable;


public class CourseBean implements Serializable{
    private static final long serialVersionUID=1L;

    private String courseName;

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}
