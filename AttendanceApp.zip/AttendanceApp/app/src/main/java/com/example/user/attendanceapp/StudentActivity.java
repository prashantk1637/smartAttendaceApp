package com.example.user.attendanceapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class StudentActivity extends AppCompatActivity {

    EditText rollField;
    String rollno,data;
    ProgressDialog progressDialog;
    ListView listView;
    Button btn;
    TextView CN,AT;
    ArrayList<AttendanceReportBeanForStudentView> reportList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        rollField=(EditText)findViewById(R.id.rollField);
        btn=(Button)findViewById(R.id.viewAttedance);
        listView=(ListView)findViewById(R.id.attendanceListView);
        CN=(TextView)findViewById(R.id.cn);
        AT=(TextView)findViewById(R.id.at);
    }


    public void viewReport(View view)
    {
        rollno=rollField.getText().toString().trim();
        rollField.setVisibility(View.GONE);
        btn.setVisibility(View.GONE);
        CN.setVisibility(View.VISIBLE);
        AT.setVisibility(View.VISIBLE);


        connectNetwork();
    }
    void connectNetwork()
    {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        new AsyncTask<String , Void,String>(){
            @Override
            protected String doInBackground(String... params) {
                String rl=params[0];
                try{

                    URL url=new URL(Url.url+"/AttendanceAppServer/student");
                    HttpURLConnection con=(HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setDoInput(true);
                    con.setDoOutput(true);
                    String msg="roll="+ URLEncoder.encode(rl,"utf-8");
                    con.getOutputStream().write(msg.getBytes());
                    DataInputStream dis=new DataInputStream(con.getInputStream());
                    data=dis.readLine();



                }catch (Exception e){}

                return data;

            }

            @Override
            protected void onPostExecute(String attendance) {
                super.onPostExecute(attendance);
                progressDialog.dismiss();
                String [] attend=attendance.split(":");
                ArrayList<String> list=new ArrayList<>();
                for(int i=0;i<attend.length;i++)
                {
                       list.add(attend[i]);

                }
                ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(StudentActivity.this,android.R.layout.simple_dropdown_item_1line,list);
                listView.setAdapter(arrayAdapter);




            }
        }.execute(rollno);





    }
}
