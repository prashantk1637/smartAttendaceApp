package com.example.user.attendanceapp;

import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

/**
 * Created by Prashant Kumar on 7/26/2017.
 */

public class ViewHolder {
    TextView Name;
    TextView roll;
    RadioGroup radioGroup;
    RadioButton present;
    RadioButton absent;
}
