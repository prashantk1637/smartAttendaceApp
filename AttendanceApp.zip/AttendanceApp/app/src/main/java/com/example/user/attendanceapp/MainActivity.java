package com.example.user.attendanceapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.sax.RootElement;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.DataInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    TextView teacherName, courseName;
    ProgressDialog progressDialog;
    String student;
    String course, teacher;
    RadioButton present,absent;
    RadioGroup radioGroup;
    TextView nameTextView,rollTextView,timeView;
    MyAdapter myAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        teacherName = (TextView) findViewById(R.id.teacherName);
        courseName = (TextView) findViewById(R.id.courseName);
        listView = (ListView) findViewById(R.id.listView);
        radioGroup=(RadioGroup)findViewById(R.id.radiogrp);
        present=(RadioButton)findViewById(R.id.present);
        absent=(RadioButton)findViewById(R.id.absent);
        nameTextView=(TextView) findViewById(R.id.name);
        rollTextView= (TextView)findViewById(R.id.roll);
        timeView=(TextView)findViewById(R.id.timeView);
        Intent intent = getIntent();
        course = intent.getStringExtra("course");
        teacher = intent.getStringExtra("teacher");
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Fetching Student list...");
        progressDialog.show();
        connectNetwork();

    }

    void connectNetwork() {
        new AsyncTask<String, Void, String>() {
            @Override
            protected String doInBackground(String... params) {
                String crs = params[0];
                try {

                    URL url = new URL(Url.url+"/AttendanceAppServer/fetchstudent");
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setDoInput(true);
                    con.setDoOutput(true);
                    String msg = "course=" + URLEncoder.encode(crs, "utf-8");
                    con.getOutputStream().write(msg.getBytes());
                    DataInputStream dis = new DataInputStream(con.getInputStream());
                    student = dis.readLine();

                } catch (Exception e) {
                }

                return student;

            }

            @Override
            protected void onPostExecute(String students) {
                super.onPostExecute(students);
                progressDialog.dismiss();
                if(students==null)
                {
                    Toast.makeText(MainActivity.this,"No students are assigned yet with this course",Toast.LENGTH_LONG).show();
                    return;
                }
                String[] student = students.split(":");
                ArrayList<StudentDetails> list = new ArrayList<>();
                for (int i = 0; i < student.length; i++) {
                   // Toast.makeText(MainActivity.this,student[i],Toast.LENGTH_LONG).show();
                   StudentDetails s=new StudentDetails();
                        s.setRoll(student[i]);
                        s.setName(student[i+1]);
                    list.add(s);
                    i++;
                }
                teacherName.setText("Teacher id: "+teacher);
                courseName.setText("Course: "+course);
                Date d = new Date();
                DateFormat df = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
                String time = df.format(d);
                timeView.setText("Time: "+time);
               myAdapter = new MyAdapter(MainActivity.this,R.layout.single_student_details, list,teacher,course,time);

               listView.setAdapter(myAdapter);


            }
        }.execute(course);
    }

    public void submitAttendance(View v)
    {
       myAdapter.printData();


    }
}
