package com.example.user.attendanceapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.inputmethodservice.Keyboard;
import android.os.AsyncTask;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.DataInputStream;
import java.io.ObjectInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * Created by User on 7/19/2017.
 */

public class MyAdapter extends ArrayAdapter<StudentDetails> {
    Context context;
    int layoutResourceId;
    String teacher,course,time;
    private int j=1;
    String attend;
    ArrayList<AttendanceReport> reportList=null;

    public MyAdapter(Context context,int layoutResourceId, ArrayList<StudentDetails> s, String teacher,String course,String time) {
        super(context,layoutResourceId, s);
        this.context=context;
        this.layoutResourceId=layoutResourceId;
        this.teacher=teacher;
        this.course=course;
        this.time=time;
        reportList=new ArrayList<>();


    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable final View convertView, @NonNull ViewGroup parent) {
        View row=convertView;
        ViewHolder viewHolder=null;
        if(row==null) {
            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
            row = inflater.inflate(layoutResourceId, parent, false);
            viewHolder=new ViewHolder();

            viewHolder.Name=(TextView)row.findViewById(R.id.name);
            viewHolder.roll=(TextView)row.findViewById(R.id.roll);
            viewHolder.radioGroup=(RadioGroup)row.findViewById(R.id.radiogrp);
            viewHolder.present=(RadioButton)row.findViewById(R.id.present);
            viewHolder.absent=(RadioButton)row.findViewById(R.id.absent);
            viewHolder.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                    AttendanceReport report=new AttendanceReport();
                    if(checkedId==R.id.present)
                    {   report.setName(getItem(position).getName());
                        report.setRoll(getItem(position).getRoll());
                        report.setStatus("Present");
                    }
                    else if(checkedId==R.id.absent)
                    {
                        report.setName(getItem(position).getName());
                        report.setRoll(getItem(position).getRoll());
                        report.setStatus("Absent");

                    }

                        reportList.add(report);

                }
            });

            row.setTag(viewHolder);


        }
        else
        {
            viewHolder=(ViewHolder)row.getTag();
        }
        StudentDetails s1 = getItem(position);
        viewHolder.Name.setText(s1.getName());
        viewHolder.roll.setText(s1.getRoll());


        return row;
    }
    public void printData()
    { int presentCount=0;
        int absentCount=0;
       attend=teacher+"#"+course+"#"+time+"#";
        for(AttendanceReport r: reportList)
        {
            attend+=r.getRoll()+"#"+r.getName()+"#"+r.getStatus()+"#";
            if(r.getStatus().equals("Present"))
                presentCount++;
            if(r.getStatus().equals("Absent"))
                absentCount++;

        }
        new AlertDialog.Builder(context)
                .setTitle("Attendance Report")
                .setMessage("Total present students: "+presentCount+"\n"+"Total absent students: "+absentCount)
                .setPositiveButton("Submit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        connectNetwork();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();


    }
    ProgressDialog progressDialog;
   public void connectNetwork()
   {
       progressDialog=new ProgressDialog(context);
       progressDialog.setMessage("Submitting your data");
       progressDialog.show();
       new AsyncTask<String , Void, String>(){
           @Override
           protected String doInBackground(String... params) {
               String report=params[0];

               try{

                   URL url=new URL(Url.url+"/AttendanceAppServer/report");
                   HttpURLConnection con=(HttpURLConnection) url.openConnection();
                   con.setRequestMethod("POST");
                   con.setDoInput(true);
                   con.setDoOutput(true);
                   String msg="report="+ URLEncoder.encode(report,"utf-8");
                   con.getOutputStream().write(msg.getBytes());
                   DataInputStream dis=new DataInputStream(con.getInputStream());
                   String result=dis.readLine();
                   return result;

               }catch (Exception e){}

               return null;

           }

           @Override
           protected void onPostExecute(String result) {
               super.onPostExecute(result);
               progressDialog.dismiss();
               if(Integer.parseInt(result.trim())>0)
                Toast.makeText(context,"Data Submitted",Toast.LENGTH_LONG).show();

           }
       }.execute(attend);
   }


}
