package com.example.user.attendanceapp;

public class Url {
    public static final String url="http://192.168.43.35:9092";
}
