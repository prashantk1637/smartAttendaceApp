package com.example.user.attendanceapp;

/**
 * Created by Prashant Kumar on 8/3/2017.
 */

public class AttendanceReportBeanForStudentView {
    private String course;
    private String attendance;

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getAttendance() {
        return attendance;
    }

    public void setAttendance(String attendance) {
        this.attendance = attendance;
    }
}
