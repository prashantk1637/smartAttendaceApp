package com.example.user.attendanceapp;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class LoginActivity extends AppCompatActivity {

    EditText email,pass;
    String user,password;
    String name;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email=(EditText)findViewById(R.id.email);
        pass=(EditText)findViewById(R.id.password);
        if (NetworkStatus.getInstance(this).isOnline()) {

            //Toast.makeText(this,"You are online!!!!",Toast.LENGTH_LONG).show();

        } else {

            Toast.makeText(this,"Check INTERNET Connection!!!!",Toast.LENGTH_LONG).show();
        }

    }
    public void studentPanel(View v)
    {
        startActivity(new Intent(this,StudentActivity.class));
    }
    public void login(View v)
    {
        user=email.getText().toString().trim();
        password=pass.getText().toString().trim();
        progressDialog =new ProgressDialog(LoginActivity.this);
        progressDialog.setMessage("Signing In...");
        progressDialog.show();
        if(ContextCompat.checkSelfPermission(LoginActivity.this,"android.permission.INTERNET")!= PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(LoginActivity.this,new String[]{"android.permission.INTERNET"},0);

        }
        else
            connectNetwork();


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case 0:
                if(grantResults[0]==PackageManager.PERMISSION_GRANTED)
                    connectNetwork();
        }
    }

    void connectNetwork()
    {
        new AsyncTask<String , Void, User>(){
            @Override
            protected User doInBackground(String... params) {
                String uid=params[0];
                String pwd=params[1];
                User u=null;
                try{

                    URL url=new URL(Url.url+"/AttendanceAppServer/LoginServer");
                    HttpURLConnection con=(HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setDoInput(true);
                    con.setDoOutput(true);
                    String msg="uid="+ URLEncoder.encode(uid,"utf-8")+"&pwd="+URLEncoder.encode(pwd,"utf-8");
                    con.getOutputStream().write(msg.getBytes());
                    ObjectInputStream ois=new ObjectInputStream(con.getInputStream());
                    u= (User) ois.readObject();

                }catch (Exception e){}

                return u;

            }

            @Override
            protected void onPostExecute(User u) {
                super.onPostExecute(u);
                progressDialog.dismiss();
               if(user.equals(u.getUser().trim())&& password.equals(u.getPass().trim())) {
                    Intent intent = new Intent(LoginActivity.this,CourseListActivity.class);
                    intent.putExtra("username", u.getUser());
                    startActivity(intent);
                }
                else
                    Toast.makeText(LoginActivity.this,"Wrong Credentials",Toast.LENGTH_LONG).show();

            }
        }.execute(user,password);





    }
}