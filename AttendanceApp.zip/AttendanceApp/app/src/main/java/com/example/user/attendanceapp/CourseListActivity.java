
package com.example.user.attendanceapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.ObjectInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class CourseListActivity extends AppCompatActivity {

    ListView listView;
    String  user;
    ProgressDialog progressDialog;
    String name="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_list);
        Intent i=getIntent();
        user=i.getStringExtra("username");
        listView=(ListView)findViewById(R.id.courselistView);
        Toast.makeText(this,"Logged in as "+user,Toast.LENGTH_LONG).show();
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Fetching Assigned Courses...");
        progressDialog.show();
        connectNetwork();

    }

    void connectNetwork()
    {
        new AsyncTask<String , Void,String>(){
            @Override
            protected String doInBackground(String... params) {
                String uid=params[0];
                try{

                    URL url=new URL(Url.url+"/AttendanceAppServer/fetchcourse");
                    HttpURLConnection con=(HttpURLConnection) url.openConnection();
                    con.setRequestMethod("POST");
                    con.setDoInput(true);
                    con.setDoOutput(true);
                    String msg="user="+URLEncoder.encode(uid,"utf-8");
                    con.getOutputStream().write(msg.getBytes());
                    DataInputStream dis=new DataInputStream(con.getInputStream());
                    name=dis.readLine();



                }catch (Exception e){}

                return name;

            }

            @Override
            protected void onPostExecute(String courses) {
                super.onPostExecute(courses);
                progressDialog.dismiss();
                //Toast.makeText(CourseListActivity.this,courses,Toast.LENGTH_LONG).show();

                String [] course=courses.split(":");
                ArrayList<String> list=new ArrayList<>();
                for(int i=0;i<course.length;i++)
                {
                    //Toast.makeText(CourseListActivity.this,course[i],Toast.LENGTH_LONG).show();
                    list.add(course[i]);
                }
                ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(CourseListActivity.this,android.R.layout.simple_dropdown_item_1line,list);
                listView.setAdapter(arrayAdapter);

                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent i=new Intent(CourseListActivity.this,MainActivity.class);
                        i.putExtra("course",listView.getItemAtPosition(position).toString());
                        i.putExtra("teacher",user);
                        startActivity(i);
                    }
                });



            }
        }.execute(user);





    }
}
