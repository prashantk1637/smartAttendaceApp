package com.example.user.attendanceapp;

/**
 * Created by User on 7/19/2017.
 */

public class StudentDetails {
    private String name;
    private  String roll;

    public StudentDetails(String name, String roll) {
        this.name = name;
        this.roll = roll;
    }
    public StudentDetails(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoll() {
        return roll;
    }

    public void setRoll(String roll) {
        this.roll = roll;
    }
}
